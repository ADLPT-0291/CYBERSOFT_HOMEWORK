
function App() {
  
  return (
      <>
        {/* Các bạn để các component ở trong đây !! */}
        <h1 className='text-danger'>Hello Cyber !</h1>
      </>
  )
}

export default App

